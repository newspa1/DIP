# DIP Homework Assignment #1
# Name: 鐘文駿
# ID #: B11902167
# email: b11902167@csie.ntu.edu.tw
python3 hw1.py
