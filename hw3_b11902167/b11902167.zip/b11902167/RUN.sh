# DIP Homework Assignment #1
# Name: 鐘文駿
# ID #: B11902167
# email: b11902167@csie.ntu.edu.tw
python3 hw3.py 1
python3 hw3.py 2
python3 hw3.py 3
python3 hw3.py 4
python3 hw3.py 5
python3 hw3.py 6
python3 hw3.py 7